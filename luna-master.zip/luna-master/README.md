# Luna

**We've made this theme code public so that other [theme developers](https://help.bigcartel.com/developers/themes/) can learn from it.** It's designed to work on [Big Cartel](https://www.bigcartel.com/) or locally with [Dugway](https://github.com/bigcartel/dugway). You're welcome to download, fork, read, and run this theme. However, you are not permitted to sell, distribute, or use this theme outside of Big Cartel. Thanks.

*© 2013 Singlenaut - © 2013 Big Cartel, LLC*
